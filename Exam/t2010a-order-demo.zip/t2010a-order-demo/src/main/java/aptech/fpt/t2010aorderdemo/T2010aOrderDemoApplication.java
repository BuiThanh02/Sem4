package aptech.fpt.t2010aorderdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T2010aOrderDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(T2010aOrderDemoApplication.class, args);
    }

}
