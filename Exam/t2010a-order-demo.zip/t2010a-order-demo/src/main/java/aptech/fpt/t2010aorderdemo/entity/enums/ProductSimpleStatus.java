package aptech.fpt.t2010aorderdemo.entity.enums;

public enum ProductSimpleStatus {
    DEACTIVE, ACTIVE, DELETED, UNDEFINED;
}
