package aptech.fpt.t2010aorderdemo.repository;

import aptech.fpt.t2010aorderdemo.entity.Order;
import aptech.fpt.t2010aorderdemo.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface OrderRepository extends JpaRepository<Order, String>, JpaSpecificationExecutor<Order> {

}
