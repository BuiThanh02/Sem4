package aptech.fpt.t2010aorderdemo.repository;

import aptech.fpt.t2010aorderdemo.entity.Product;
import aptech.fpt.t2010aorderdemo.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Integer> {

}
