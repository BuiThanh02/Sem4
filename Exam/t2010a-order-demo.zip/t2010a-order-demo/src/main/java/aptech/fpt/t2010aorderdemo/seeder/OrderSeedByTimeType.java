package aptech.fpt.t2010aorderdemo.seeder;

public enum OrderSeedByTimeType {
    DAY, MONTH, YEAR
}
