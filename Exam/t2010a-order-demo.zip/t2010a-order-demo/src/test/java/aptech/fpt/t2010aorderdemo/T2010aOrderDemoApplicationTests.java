package aptech.fpt.t2010aorderdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T2010aOrderDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
