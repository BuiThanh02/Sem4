package aptech.fpt.t2010aorderdemo.seeder;

import aptech.fpt.t2010aorderdemo.entity.enums.OrderSimpleStatus;
import aptech.fpt.t2010aorderdemo.util.DateTimeHelper;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.TemporalAmount;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class OrderSeedByTimeTest {
    @Test
    public void testOrderSeedByTimeClass() {
        List<OrderSeedByTime> seeder = new ArrayList<>();
        seeder.add(
                OrderSeedByTime.builder()
                        .orderStatus(OrderSimpleStatus.DONE).seedTypeByTime(OrderSeedByTimeType.DAY).day(18).month(Month.JUNE).year(2022).orderCount(350)
                        .build());
        seeder.add(
                OrderSeedByTime.builder()
                        .orderStatus(OrderSimpleStatus.DONE).seedTypeByTime(OrderSeedByTimeType.DAY).day(17).month(Month.JUNE).year(2022).orderCount(300)
                        .build());
        seeder.add(
                OrderSeedByTime.builder()
                        .orderStatus(OrderSimpleStatus.DONE).seedTypeByTime(OrderSeedByTimeType.MONTH).month(Month.JUNE).year(2022).orderCount(250)
                        .build());
        seeder.add(
                OrderSeedByTime.builder()
                        .orderStatus(OrderSimpleStatus.PROCESSING).seedTypeByTime(OrderSeedByTimeType.MONTH).month(Month.JUNE).year(2022).orderCount(10)
                        .build());
        seeder.add(
                OrderSeedByTime.builder()
                        .orderStatus(OrderSimpleStatus.DONE).seedTypeByTime(OrderSeedByTimeType.MONTH).month(Month.MAY).year(2022).orderCount(40)
                        .build());
        seeder.add(
                OrderSeedByTime.builder()
                        .orderStatus(OrderSimpleStatus.DONE).seedTypeByTime(OrderSeedByTimeType.MONTH).month(Month.APRIL).year(2022).orderCount(50)
                        .build());
        seeder.add(
                OrderSeedByTime.builder()
                        .orderStatus(OrderSimpleStatus.PROCESSING).seedTypeByTime(OrderSeedByTimeType.MONTH).month(Month.APRIL).year(2022).orderCount(4)
                        .build());
        seeder.add(
                OrderSeedByTime.builder()
                        .orderStatus(OrderSimpleStatus.DONE).seedTypeByTime(OrderSeedByTimeType.MONTH).month(Month.MARCH).year(2022).orderCount(120)
                        .build());
    }

    @Test
    public void testDaysInMonth() {
        int month = 6;
        int year = 2022;
        LocalDateTime localDateTime = LocalDateTime.of(year, month, 1, 0, 0, 0);
        localDateTime = localDateTime.plusMonths(1).minusDays(1);
        System.out.println(localDateTime.toString());
    }

    static Random randomObj = new Random();

    @Test
    public void testRandomMonth() {
        Month[] months = Month.values();
        Month randomMonth = months[randomObj.nextInt(months.length)];
        System.out.println(randomMonth.name());
        System.out.println(randomMonth.getValue());
    }
}